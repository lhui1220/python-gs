def showb():
	print 'show b'

