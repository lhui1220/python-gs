def showa():
	print 'show a in a'

