from distutils.core import setup

setup(name='learnpkg', version='1.0.0', description='learn package in python', author='liuhui',py_modules=['suba.a', 'suba.b', 'subb.c'])
