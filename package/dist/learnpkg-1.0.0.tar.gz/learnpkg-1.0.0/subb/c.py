def showa():
	print 'show a in c'

def showc():
	print 'show c'
